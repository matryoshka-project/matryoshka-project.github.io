{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Stern_Brocot(Nat, Stream, Tree, bird, fusc, stern_brocot_recurse) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import qualified Prelude;

data Nat = Zero_nat | Suc Nat;

plus_nat :: Nat -> Nat -> Nat;
plus_nat (Suc m) n = plus_nat m (Suc n);
plus_nat Zero_nat n = n;

times_nat :: Nat -> Nat -> Nat;
times_nat Zero_nat n = Zero_nat;
times_nat (Suc m) n = plus_nat n (times_nat m n);

class Times a where {
  times :: a -> a -> a;
};

class (Times a) => Dvd a where {
};

instance Times Nat where {
  times = times_nat;
};

instance Dvd Nat where {
};

one_nat :: Nat;
one_nat = Suc Zero_nat;

class One a where {
  one :: a;
};

instance One Nat where {
  one = one_nat;
};

class Plus a where {
  plus :: a -> a -> a;
};

instance Plus Nat where {
  plus = plus_nat;
};

class (Plus a) => Semigroup_add a where {
};

class (One a, Semigroup_add a) => Numeral a where {
};

instance Semigroup_add Nat where {
};

instance Numeral Nat where {
};

minus_nat :: Nat -> Nat -> Nat;
minus_nat (Suc m) (Suc n) = minus_nat m n;
minus_nat Zero_nat n = Zero_nat;
minus_nat m Zero_nat = m;

class Minus a where {
  minus :: a -> a -> a;
};

instance Minus Nat where {
  minus = minus_nat;
};

equal_nat :: Nat -> Nat -> Bool;
equal_nat Zero_nat (Suc x2) = False;
equal_nat (Suc x2) Zero_nat = False;
equal_nat (Suc x2) (Suc y2) = equal_nat x2 y2;
equal_nat Zero_nat Zero_nat = True;

less_nat :: Nat -> Nat -> Bool;
less_nat m (Suc n) = less_eq_nat m n;
less_nat n Zero_nat = False;

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat (Suc m) n = less_nat m n;
less_eq_nat Zero_nat n = True;

divmod_nat :: Nat -> Nat -> (Nat, Nat);
divmod_nat m n =
  (if equal_nat n Zero_nat || less_nat m n then (Zero_nat, m)
    else let {
           a = divmod_nat (minus_nat m n) n;
           (q, aa) = a;
         } in (Suc q, aa));

divide_nat :: Nat -> Nat -> Nat;
divide_nat m n = fst (divmod_nat m n);

class Divide a where {
  divide :: a -> a -> a;
};

instance Divide Nat where {
  divide = divide_nat;
};

modulo_nat :: Nat -> Nat -> Nat;
modulo_nat m n = snd (divmod_nat m n);

class (Divide a, Dvd a) => Modulo a where {
  modulo :: a -> a -> a;
};

instance Modulo Nat where {
  modulo = modulo_nat;
};

data Stream a = SCons a (Stream a);

siterate :: forall a. (a -> a) -> a -> Stream a;
siterate f x = SCons x (siterate f (f x));

one_stream :: forall a. (One a) => Stream a;
one_stream = siterate id one;

instance (One a) => One (Stream a) where {
  one = one_stream;
};

stl :: forall a. Stream a -> Stream a;
stl (SCons x1 x2) = x2;

shd :: forall a. Stream a -> a;
shd (SCons x1 x2) = x1;

ap_stream :: forall a b. Stream (a -> b) -> Stream a -> Stream b;
ap_stream f x = SCons (shd f (shd x)) (ap_stream (stl f) (stl x));

plus_stream :: forall a. (Plus a) => Stream a -> Stream a -> Stream a;
plus_stream x y = ap_stream (ap_stream (siterate id plus) x) y;

instance (Plus a) => Plus (Stream a) where {
  plus = plus_stream;
};

instance (Semigroup_add a) => Semigroup_add (Stream a) where {
};

instance (Numeral a) => Numeral (Stream a) where {
};

data Num = One | Bit0 Num | Bit1 Num;

data Tree a = Node a (Tree a) (Tree a);

map_tree :: forall a b. (a -> b) -> Tree a -> Tree b;
map_tree f (Node x1 x2 x3) = Node (f x1) (map_tree f x2) (map_tree f x3);

bird :: Tree (Nat, Nat);
bird =
  Node (one_nat, one_nat)
    (map_tree (\ (m, n) -> (n, m))
      (map_tree (\ (m, n) -> (plus_nat m n, n)) bird))
    (map_tree (\ (m, n) -> (plus_nat m n, n))
      (map_tree (\ (m, n) -> (n, m)) bird));

modulo_stream :: forall a. (Modulo a) => Stream a -> Stream a -> Stream a;
modulo_stream x y = ap_stream (ap_stream (siterate id modulo) x) y;

times_stream :: forall a. (Times a) => Stream a -> Stream a -> Stream a;
times_stream x y = ap_stream (ap_stream (siterate id times) x) y;

minus_stream :: forall a. (Minus a) => Stream a -> Stream a -> Stream a;
minus_stream x y = ap_stream (ap_stream (siterate id minus) x) y;

numeral :: forall a. (Numeral a) => Num -> a;
numeral (Bit1 n) = let {
                     m = numeral n;
                   } in plus (plus m m) one;
numeral (Bit0 n) = let {
                     m = numeral n;
                   } in plus m m;
numeral One = one;

fusca :: Stream Nat;
fusca =
  SCons one_nat
    (minus_stream (plus_stream (SCons one_nat fusca) fusca)
      (times_stream (numeral (Bit0 One))
        (modulo_stream (SCons one_nat fusca) fusca)));

fusc :: Stream Nat;
fusc = SCons one_nat fusca;

stern_brocot_recurse :: Tree (Nat, Nat);
stern_brocot_recurse =
  Node (one_nat, one_nat)
    (map_tree (\ (m, n) -> (n, m))
      (map_tree (\ (m, n) -> (plus_nat m n, n))
        (map_tree (\ (m, n) -> (n, m)) stern_brocot_recurse)))
    (map_tree (\ (m, n) -> (plus_nat m n, n)) stern_brocot_recurse);

}
