{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Calculator(Nat, Num, Sp_mu, Sp_nu, restart, f, g) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import qualified Prelude;

data Nat = Zero_nat | Suc Nat;

data Num = One | Bit0 Num | Bit1 Num;

data Sp_mu a b c = Get (a -> Sp_mu a b c) | Put b c;

newtype Sp_nu a b = In (Sp_mu a b (Sp_nu a b));

plus_nat :: Nat -> Nat -> Nat;
plus_nat (Suc m) n = plus_nat m (Suc n);
plus_nat Zero_nat n = n;

times_nat :: Nat -> Nat -> Nat;
times_nat Zero_nat n = Zero_nat;
times_nat (Suc m) n = plus_nat n (times_nat m n);

equal_nat :: Nat -> Nat -> Bool;
equal_nat Zero_nat (Suc x2) = False;
equal_nat (Suc x2) Zero_nat = False;
equal_nat (Suc x2) (Suc y2) = equal_nat x2 y2;
equal_nat Zero_nat Zero_nat = True;

out :: forall a b. Sp_nu a b -> Sp_mu a b (Sp_nu a b);
out (In x) = x;

get :: forall a b. (a -> Sp_nu a b) -> Sp_nu a b;
get f = In (Get (\ a -> out (f a)));

minus_nat :: Nat -> Nat -> Nat;
minus_nat (Suc m) (Suc n) = minus_nat m n;
minus_nat Zero_nat n = Zero_nat;
minus_nat m Zero_nat = m;

less_nat :: Nat -> Nat -> Bool;
less_nat m (Suc n) = less_eq_nat m n;
less_nat n Zero_nat = False;

less_eq_nat :: Nat -> Nat -> Bool;
less_eq_nat (Suc m) n = less_nat m n;
less_eq_nat Zero_nat n = True;

one_nat :: Nat;
one_nat = Suc Zero_nat;

restart :: (Nat -> Sp_nu Nat Nat) -> Nat -> Sp_nu Nat Nat;
restart f n =
  (if less_nat Zero_nat n then In (Put n (restart f (minus_nat n one_nat)))
    else In (out (f Zero_nat)));

nat_of_num :: Num -> Nat;
nat_of_num (Bit1 n) = let {
                        m = nat_of_num n;
                      } in Suc (plus_nat m m);
nat_of_num (Bit0 n) = let {
                        m = nat_of_num n;
                      } in plus_nat m m;
nat_of_num One = one_nat;

f :: Nat -> Sp_nu Nat Nat;
f n = In (Put n
           (get (\ v ->
                  (if not (equal_nat v Zero_nat)
                    then f (plus_nat (times_nat (nat_of_num (Bit0 One)) v) n)
                    else restart f (plus_nat v n)))));

g :: Nat -> Sp_nu Nat Nat;
g m = In (Put (times_nat (nat_of_num (Bit0 One)) m)
           (get (\ v ->
                  (if equal_nat v Zero_nat
                    then restart g (times_nat (nat_of_num (Bit0 One)) m)
                    else g (plus_nat v m)))));

}
