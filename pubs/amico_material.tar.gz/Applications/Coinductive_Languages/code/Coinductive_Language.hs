{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module
  Coinductive_Language(Nat, Language, nota, zero, one, atom, full, plus, plusa,
                        timesa, star, inter, times, shuffle, in_language)
  where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import qualified Prelude;

data Nat = Zero_nat | Suc Nat;

data Language a = Lang Bool (a -> Language a);

take :: forall a. Nat -> [a] -> [a];
take n [] = [];
take n (x : xs) = (case n of {
                    Zero_nat -> [];
                    Suc m -> x : take m xs;
                  });

hd :: forall a. [a] -> a;
hd (x21 : x22) = x21;

tl :: forall a. [a] -> [a];
tl [] = [];
tl (x21 : x22) = x22;

gen_length :: forall a. Nat -> [a] -> Nat;
gen_length n (x : xs) = gen_length (Suc n) xs;
gen_length n [] = n;

oo :: forall a. Language a -> Bool;
oo (Lang x1 x2) = x1;

dd :: forall a. Language a -> a -> Language a;
dd (Lang x1 x2) = x2;

nota :: forall a. Language a -> Language a;
nota r = Lang (not (oo r)) (\ a -> nota (dd r a));

zero :: forall a. Language a;
zero = Lang False (\ _ -> zero);

one :: forall a. Language a;
one = Lang True (\ _ -> zero);

atom :: forall a. (Eq a) => a -> Language a;
atom a = Lang False (\ b -> (if a == b then one else zero));

full :: forall a. Language a;
full = Lang True (\ _ -> full);

plus :: forall a. [Language a] -> Language a;
plus xs = Lang (any oo xs) (\ a -> plus (map (\ r -> dd r a) xs));

plusa :: forall a. Language a -> Language a -> Language a;
plusa r s = Lang (oo r || oo s) (\ a -> plusa (dd r a) (dd s a));

timesa :: forall a. Language a -> Language a -> Language a;
timesa r s =
  Lang (oo r && oo s)
    (\ a ->
      (if oo r then plusa (timesa (dd r a) s) (dd s a) else timesa (dd r a) s));

star :: forall a. Language a -> Language a;
star r = Lang True (\ a -> timesa (dd r a) (star r));

inter :: forall a. Language a -> Language a -> Language a;
inter r s = Lang (oo r && oo s) (\ a -> inter (dd r a) (dd s a));

size_list :: forall a. [a] -> Nat;
size_list = gen_length Zero_nat;

tails :: forall a. [a] -> [[a]];
tails [] = [[]];
tails (x : xs) = (x : xs) : tails xs;

times :: forall a. [Language a] -> Language a;
times xs =
  Lang (all oo xs)
    (\ a ->
      let {
        n = size_list (takeWhile oo xs);
      } in plus (map (\ zs -> times (dd (hd zs) a : tl zs))
                  (take (Suc n) (tails (xs ++ [one])))));

shuffle :: forall a. Language a -> Language a -> Language a;
shuffle r s =
  Lang (oo r && oo s) (\ a -> plusa (shuffle (dd r a) s) (shuffle r (dd s a)));

in_language :: forall a. Language a -> [a] -> Bool;
in_language l [] = oo l;
in_language l (x : xs) = in_language (dd l x) xs;

}
