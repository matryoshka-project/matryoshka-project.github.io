{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module Stream_Processor(Stream, Sp_mu, Sp_nu, run, copy, sp_comp) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import qualified Prelude;

data Stream a = SCons a (Stream a);

data Sp_mu a b c = Get (a -> Sp_mu a b c) | Put b c;

newtype Sp_nu a b = In (Sp_mu a b (Sp_nu a b));

shd :: forall a. Stream a -> a;
shd (SCons x1 x2) = x1;

stl :: forall a. Stream a -> Stream a;
stl (SCons x1 x2) = x2;

out :: forall a b. Sp_nu a b -> Sp_mu a b (Sp_nu a b);
out (In x) = x;

get :: forall a b. (a -> Sp_nu a b) -> Sp_nu a b;
get f = In (Get (\ a -> out (f a)));

run :: forall a b. Sp_nu a b -> Stream a -> Stream b;
run sp s = (case out sp of {
             Get f -> run (In (f (shd s))) (stl s);
             Put b spa -> SCons b (run spa s);
           });

copy :: forall a. Sp_nu a a;
copy = In (Get (\ a -> Put a copy));

sp_comp :: forall a b c. Sp_nu a b -> Sp_nu c a -> Sp_nu c b;
sp_comp spa sp = (case (out spa, out sp) of {
                   (Get _, Get g) -> get (\ a -> sp_comp spa (In (g a)));
                   (Get f, Put b a) -> sp_comp (In (f b)) a;
                   (Put b spaa, _) -> In (Put b (sp_comp spaa sp));
                 });

}
