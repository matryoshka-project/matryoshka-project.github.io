{-# LANGUAGE EmptyDataDecls, RankNTypes, ScopedTypeVariables #-}

module KMP(Language, is_substring_of) where {

import Prelude ((==), (/=), (<), (<=), (>=), (>), (+), (-), (*), (/), (**),
  (>>=), (>>), (=<<), (&&), (||), (^), (^^), (.), ($), ($!), (++), (!!), Eq,
  error, id, return, not, fst, snd, map, filter, concat, concatMap, reverse,
  zip, null, takeWhile, dropWhile, all, any, Integer, negate, abs, divMod,
  String, Bool(True, False), Maybe(Nothing, Just));
import qualified Prelude;

data Language a = Lang Bool (a -> Language a);

dd :: forall a. Language a -> a -> Language a;
dd (Lang x1 x2) = x2;

tl :: forall a. [a] -> [a];
tl [] = [];
tl (x21 : x22) = x22;

hd :: forall a. [a] -> a;
hd (x21 : x22) = x21;

tab :: forall a. (Eq a) => [a] -> (a -> Language a) -> Language a;
tab xs failure =
  Lang (null xs)
    (\ c ->
      (if null xs || not (hd xs == c) then failure c
        else tab (tl xs) (dd (failure c))));

aux :: forall a. (Eq a) => [a] -> (a -> Language a) -> a -> Language a;
aux xs failure = dd (tab xs failure);

oo :: forall a. Language a -> Bool;
oo (Lang x1 x2) = x1;

match :: forall a. Language a -> [a] -> Bool;
match l [] = oo l;
match l (x : xs) = oo l || match (dd l x) xs;

table :: forall a. (Eq a) => [a] -> Language a;
table xs = Lang (null xs) (aux xs (\ _ -> table xs));

is_substring_of :: forall a. (Eq a) => [a] -> [a] -> Bool;
is_substring_of xs ys = match (table xs) ys;

}
