This archive contains supplementary material related to the paper

  Friends with Benefits: Implementing Foundational Corecursion in Proof Assistants

The archive provides 

  a) the implementation of the package;
  b) the examples from Sections 1, 3, and 4;
  c) the examples from Blanchette et al. (ICFP 2015); and
  d) the applications from Section 2 and the Appendix A.

The implementation and the formalizations have been processed with the
Isabelle2016-1 release.


1. Installing Isabelle

You can download the Isabelle2016-1 release as an application bundle from 

  http://isabelle.in.tum.de/website-Isabelle2016-1/

Please follow the installation instructions on the Isabelle website

  http://isabelle.in.tum.de/website-Isabelle2016-1/installation.html


2. Content of the archive

a) The implementation of the package is in the file BNF_Corec.thy and
the ML files in Tools.

b) The examples are in the file Examples.thy.

c) The applications are in the folder Applications with separate
subfolders.

d) All applications except for LFilter contain a subfolder code/ with the
generated Haskell code.

e) The folder AFP contains the entries from the Archive of Formal
Proofs (www.isa-afp.org) which the applications require (AFP for Isabelle2016-1).
They are not part of the contribution and included only for completeness.

f) The folder HTML contains the .html files generated from the raw
Isabelle files (see below).


3. Processing the formalization

To process all of the formalization, run the command

  ./bin/isabelle build -o browser_info -v -D <path_to_archive_folder>

where <path_to_archive_folder> denotes the folder into which you have
extracted the archive.  The Isabelle application script is in the
"bin" folder of the distribution.  Processing checks that all
definitions and proofs are correct, extracts the code to Haskell in
the code/ subfolders of the applications, and generates .html files from the
formalization to be used for browsing.  The location of HTML files is
shown at the end of the processing output.  The archive also contains
the pregenerated HTML files in the folder HTML.

To launch the graphical interface Isabelle/jEdit, run the command

  ./bin/isabelle jedit

and select a .thy file to open.


4. Code extraction

The code/ subfolder of the application folders (except for LFilter)
contains the Haskell code extracted from the formalisations. The modules
can be compiled with GHC (tested with 7.6.3).  The code contains only
the extracted (co)datatype and HOL function definitions.  In particular, 
there are no main function and no Read or Show instances.  To run them,
one has to supply inputs and pretty-print the results manually.


5. AmiCo in the Isabelle development version

AmiCo is part of the Isabelle 2016-1 release. The implementation of AmiCo
can be found in src/HOL/Library/BNF_Corec.thy and
src/HOL/Tools/BNF/bnf_gfp_grec*.ML. Some of the examples can be found
in src/HOL/Corec_Examples.

You can find more documentation on AmiCo by running the following
commands:

  ./bin/isabelle build_doc corec
  ./bin/isabelle doc corec
