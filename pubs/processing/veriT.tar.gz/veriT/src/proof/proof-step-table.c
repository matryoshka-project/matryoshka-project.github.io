#include "veriT-DAG.h"
#include "proof-rules.h"
#include "proof-step-hash.h"

#include "proof-step-table.h"

Tstack_proof_step_stack steps_stack = NULL;

Tstack_DAG_assoc choices;
Tstack_DAG_assoc ite_csts;

/*
  --------------------------------------------------------------
  Step stacks handling
  --------------------------------------------------------------
*/

void
steps_init(void)
{
  stack_INIT(choices);
  stack_INIT(ite_csts);

  stack_INIT(steps_stack);
  stack_inc(steps_stack);
  stack_INIT(top_steps);
  stack_push(top_steps, NULL);
  steps_hash = hash_new(100,
                        (TFhash) steps_hash_function,
                        (TFequal) steps_hash_equal,
                        (TFfree) steps_hash_free);
}

/*--------------------------------------------------------------*/

Tproof
steps_push(Tproof_step proof_step)
{
  proof_step = proof_step_clean(proof_step);
  if (!proof_step->type)
    my_error("steps_push: proof_step without type\n");
  stack_push(top_steps, proof_step);
  if (stack_is_empty(proof_step->DAGs))
    empty_clause = stack_size(top_steps) - 1;
#ifdef DEBUG_PROOF
  my_message("Adding step (%d)\n", stack_size(top_steps) - 1);
  proof_step_print(proof_step, top_steps, stack_size(top_steps) - 1, stderr);
#endif
  return stack_size(top_steps) - 1;
}

/*--------------------------------------------------------------*/

void
steps_prune(void)
{
  unsigned i, j, max;
  Tproof_step proof_step;
  Tproof_type type;
  assert(!stack_is_empty(top_steps));
  assert(stack_size(steps_stack) == 1);
  while (stack_size(top_steps) > 0 &&
         stack_size(stack_top(top_steps)->DAGs) != 0)
    stack_dec(top_steps);
  assert(stack_size(top_steps) > 0);
  assert(stack_size(stack_top(top_steps)->DAGs) == 0);
  /* PF first mark all used clauses (from the end) with misc */
  stack_top(top_steps)->misc = 1;
  for (i = stack_size(top_steps); --i > 0; )
    {
      proof_step = stack_get(top_steps, i);
      type = proof_step->type;
      max = 0;
      if (!proof_step->misc)
        continue;
      if (type >= ps_type_subproof)
        continue;
      assert(ps_type_desc[type].nb_reasons != -1 ||
             ps_type_desc[type].nb_params == 0);
      assert(ps_type_desc[type].nb_reasons == -1 ||
             (proof_step->reasons &&
              (((unsigned) ps_type_desc[type].nb_reasons) +
               ps_type_desc[type].nb_params == stack_size(proof_step->reasons))));
      max = (ps_type_desc[type].nb_reasons == -1)?
        stack_size(proof_step->reasons) :
        ((unsigned) ps_type_desc[type].nb_reasons);
      for (j = 0; j < max; ++j)
        stack_get(top_steps, stack_get(proof_step->reasons, j))->misc = 1;
    }
  /* PF number all used clauses in a dense manner */
  for (i = 1, j = 1; i < stack_size(top_steps); ++i)
    if (stack_get(top_steps, i)->misc)
      stack_get(top_steps, i)->misc = j++;
  /* PF renumber clause_ids, and eliminate all unused clauses */
  for (i = 1; i < stack_size(top_steps); i++)
    {
      proof_step = stack_get(top_steps, i);
      type = proof_step->type;
      max = 0;
      if (!proof_step->misc)
        {
          proof_step_free(&proof_step);
          stack_set(top_steps, i, NULL);
          continue;
        }
      if (type >= ps_type_subproof)
        continue;
      assert(ps_type_desc[type].nb_reasons != -1 || proof_step->reasons);
      max = (ps_type_desc[type].nb_reasons == -1)?
        stack_size(proof_step->reasons) :
        ((unsigned) ps_type_desc[type].nb_reasons);
      for (j = 0; j < max; ++j)
        stack_set(proof_step->reasons, j,
                  stack_get(top_steps,
                            stack_get(proof_step->reasons, j))->misc);
    }
  /* PF eliminate all the garbage */
  i = 1; j = 1;
  while (i < stack_size(top_steps))
    {
      proof_step = stack_get(top_steps, i);
      if (proof_step)
        {
          stack_set(top_steps, j++, proof_step);
          proof_step->misc = 0;
        }
      i++;
    }
  stack_resize(top_steps, j);
}

/*--------------------------------------------------------------*/

void
steps_merge(void)
{
  unsigned i, j, max;
  Tproof_step proof_step;
  Tproof proof_id;
  Tproof_type type;

  assert(stack_size(steps_stack) == 1);
  /* PF first enter every clause into a hash table, and mark all
     repeated clauses with the number of the original one */
  for (i = 1; i < stack_size(top_steps); ++i)
    {
      proof_id = steps_hash_get(stack_get(top_steps, i));
      if (proof_id)
        stack_get(top_steps, i)->misc = proof_id;
      else
        steps_hash_push(stack_get(top_steps, i), i);
    }
  /* PF renumber clause_ids */
  for (i = 1; i < stack_size(top_steps); ++i)
    {
      proof_step = stack_get(top_steps, i);
      type = proof_step->type;
      max = 0;
      if (type >= ps_type_subproof)
        continue;
      assert(ps_type_desc[type].nb_reasons != -1 || proof_step->reasons);
      max = (ps_type_desc[type].nb_reasons == -1)?
        stack_size(proof_step->reasons) :
        ((unsigned) ps_type_desc[type].nb_reasons);
      for (j = 0; j < max; ++j)
        if (stack_get(top_steps, stack_get(proof_step->reasons, j))->misc)
          stack_set(proof_step->reasons, j,
                    stack_get(top_steps,
                              stack_get(proof_step->reasons, j))->misc);
    }
  /* PF remove from hash table and tidy */
  for (i = 1; i < stack_size(top_steps); ++i)
    {
      steps_hash_remove(stack_get(top_steps, i));
      stack_get(top_steps, i)->misc = 0;
    }
}

/*--------------------------------------------------------------*/

void
steps_done(void)
{
  unsigned i;
  assert(stack_size(steps_stack) == 1);
  if (!top_steps)
    my_error("steps_done: no steps_init\n");
  for (i = 1; i < stack_size(top_steps); ++i)
    {
      Tproof_step proof_step = stack_get(top_steps, i);
      proof_step_free(&proof_step);
    }
  if (stack_get(top_steps, 0))
    my_error("proof_steps_done: internal error\n");
  for (i = 0; i < stack_size(choices); ++i)
    {
      DAG_free(stack_get(choices, i).src);
      DAG_free(stack_get(choices, i).dest);
    }
  stack_free(choices);
  for (i = 0; i < stack_size(ite_csts); ++i)
    {
      DAG_free(stack_get(ite_csts, i).src);
      DAG_free(stack_get(ite_csts, i).dest);
    }
  stack_free(ite_csts);
  stack_free(top_steps);
  stack_free(steps_stack);
  hash_free(&steps_hash);
}
