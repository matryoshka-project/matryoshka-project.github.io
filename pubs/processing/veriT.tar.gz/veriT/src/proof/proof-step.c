#include "general.h"
#include "polarities.h"
#include "DAG.h"
#include "DAG-symb.h"
#include "DAG-tmp.h"
#include "veriT-DAG.h"

#include "proof-step.h"

#define get_atom(D) (DAG_symb(D) == CONNECTOR_NOT? DAG_arg0(D) : D)

Tproof_step
proof_step_new(void)
{
  Tproof_step proof_step = NULL;
  MY_MALLOC(proof_step, sizeof(struct TSproof_step));
  proof_step->type = ps_type_none;
  stack_INIT(proof_step->DAGs);
  proof_step->misc = 0;
  proof_step->reasons = NULL;
  proof_step->args = NULL;
  proof_step->subproof_steps = NULL;
  return proof_step;
}

/*--------------------------------------------------------------*/

void
proof_step_free(Tproof_step * Pproof_step)
{
  unsigned i;
  Tstack_proof_step steps;
  if (!*Pproof_step)
    return;
  assert((*Pproof_step)->DAGs);
  stack_apply((*Pproof_step)->DAGs, DAG_free);
  stack_free((*Pproof_step)->DAGs);
  /* assert(!(*Pproof_step)->misc); */
  if ((*Pproof_step)->reasons)
    stack_free((*Pproof_step)->reasons);
  if ((*Pproof_step)->type >= ps_type_subproof)
    {
      if ((*Pproof_step)->args)
        {
          assert(!stack_is_empty((*Pproof_step)->args));
          /* Last element is always the number of bound variables, not a DAG */
          stack_dec((*Pproof_step)->args);
          stack_apply((*Pproof_step)->args, DAG_free);
          stack_free((*Pproof_step)->args);
        }
      steps = (*Pproof_step)->subproof_steps;
      if (steps)
        {
          for (i = 1; i < stack_size(steps); ++i)
            proof_step_free(&stack_get(steps, i));
          if (stack_get(steps, 0))
            my_error("proof_step_free: internal error\n");
          stack_free(steps);
        }
    }
  else
    if ((*Pproof_step)->args)
      {
        stack_apply((*Pproof_step)->args, DAG_free);
        stack_free((*Pproof_step)->args);
      }
  free(*Pproof_step);
  *Pproof_step = NULL;
}

/*--------------------------------------------------------------*/

void
proof_step_add_DAG(Tproof_step proof_step, TDAG DAG)
{
  stack_push(proof_step->DAGs, DAG);
}

/*--------------------------------------------------------------*/

void
proof_step_add_arg(Tproof_step proof_step, TDAG DAG)
{
  assert(proof_step->type < ps_type_subproof);
  if (!proof_step->args)
    stack_INIT(proof_step->args);
  stack_push(proof_step->args, DAG);
}

/*--------------------------------------------------------------*/

void
proof_step_add_reason(Tproof_step proof_step, Tproof proof_id)
{
  if (!proof_step->reasons)
    stack_INIT(proof_step->reasons);
  stack_push(proof_step->reasons, proof_id);
}

/*--------------------------------------------------------------*/

/* #define get_pol(D) (DAG_symb(D) == CONNECTOR_NOT? POL_NEG : POL_POS) */

/*--------------------------------------------------------------*/

/* [TODO] get rid of this and use Tpol */
static int
DAG_polarity(TDAG DAG)
/* PF returns the polarity of a literal */
{
  int polarity = 1;
  while (DAG_symb(DAG) == CONNECTOR_NOT)
    {
      DAG = DAG_arg0(DAG);
      polarity = ~polarity;
    }
  return polarity & 1;
}

/* [TODO] how to not use DAG_misc given that DAG_tmp may be in use by the
   modules calling this function? */
Tproof_step
proof_step_clean(Tproof_step proof_step)
{
  unsigned i, tmp;
  Tproof_step result;
  /* PF check for valid clauses, and use loop to detect
     if literals to eliminate (NOT X=X or repeated) */
  for (tmp = 0, i = 0; i < stack_size(proof_step->DAGs); ++i)
    {
      TDAG DAG = stack_get(proof_step->DAGs, i);
      int pol = DAG_polarity(stack_get(proof_step->DAGs, i));
      while (DAG_symb(stack_get(proof_step->DAGs, i)) == CONNECTOR_NOT &&
             DAG_symb(DAG_arg0(stack_get(proof_step->DAGs, i))) == CONNECTOR_NOT)
        {
          stack_get(proof_step->DAGs, i) = DAG_dup(DAG_arg0(DAG_arg0(DAG)));
          DAG_free(DAG);
          DAG = stack_get(proof_step->DAGs, i);
        }
      DAG = get_atom(DAG);
      if (DAG_misc(DAG))
        {
          DAG_misc_set(DAG, DAG_misc(DAG) | (pol? POL_POS : POL_NEG));
          if (DAG_misc(DAG) == POL_BOTH)
            {
              tmp = 2; /* Valid clause */
              break;
            }
          tmp = 1; /* Literal to eliminate */
        }
      else
        DAG_misc_set(DAG, DAG_misc(DAG) | (pol ? POL_POS : POL_NEG));
    }
  if (tmp == 0)
    {
      /* No transformation has to occur */
      for (i = 0; i < stack_size(proof_step->DAGs); ++i)
        DAG_misc_set(get_atom(stack_get(proof_step->DAGs, i)), 0);
      return proof_step;
    }
  result = proof_step_new();
  result->type = proof_step->type;
  if (proof_step->type < ps_type_subproof)
    {
      result->reasons = NULL;
      if (proof_step->reasons)
        stack_COPY(result->reasons, proof_step->reasons);
      result->args = NULL;
      if (proof_step->args)
        stack_COPY(result->args, proof_step->args);
    }
  else
    {
      assert(ps_type_subproof || proof_step->args);
      result->args = NULL;
      if (proof_step->args)
        stack_COPY(result->args, proof_step->args);
      assert(proof_step->subproof_steps);
      stack_COPY(result->subproof_steps, proof_step->subproof_steps);
    }
  if (tmp == 2)
    {
      /* Valid clause */
      for (i = 0; i < stack_size(proof_step->DAGs); ++i)
        DAG_misc_set(get_atom(stack_get(proof_step->DAGs, i)), 0);
      proof_step_add_DAG(result, DAG_dup(DAG_TRUE));
#ifdef DEBUG_PROOF
      my_message("proof_step_clean: proof_step:\n");
      proof_step_print(proof_step, top_steps, 0, stderr);
      my_message("result:\n");
      proof_step_print(result, top_steps, 0, stderr);
#endif
      proof_step_free(&proof_step);
      return result;
    }
  /* Literal to eliminate */
  for (i = 0; i < stack_size(proof_step->DAGs); ++i)
    if (DAG_misc(get_atom(stack_get(proof_step->DAGs, i))))
      {
        proof_step_add_DAG(result, DAG_dup(stack_get(proof_step->DAGs, i)));
        DAG_misc_set(get_atom(stack_get(proof_step->DAGs, i)), 0);
      }
#ifdef DEBUG_PROOF
  my_message("proof_step_clean: proof_step:\n");
  proof_step_print(proof_step, top_steps, 0, stderr);
  my_message("result:\n");
  proof_step_print(result, top_steps, 0, stderr);
#endif
  proof_step_free(&proof_step);
  return result;
}
