#ifndef __PROOF_OUTPUT_H
#define __PROOF_OUTPUT_H

#include <stdarg.h>
#include <stdio.h>

#include "proof-step.h"
#include "proof-step-table.h"

extern void
proof_step_print_old(Tproof_step proof_step, Tstack_proof_step steps,
                     Tproof id, FILE * file);

extern void proof_step_print(Tproof_step proof_step, Tstack_proof_step steps,
                             Tproof id, FILE * file);

/**
   \author Pascal Fontaine
   \brief outputs proof to file */
extern void proof_out(FILE * file);

#endif
