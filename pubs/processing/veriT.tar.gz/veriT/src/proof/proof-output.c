#include "DAG-tmp.h"
#include "DAG-print.h"
#include "DAG-prop.h"

#include "proof-output.h"

/* [TODO] avoid this workaround */
extern bool proof_with_sharing;
extern bool option_proof_prune;
extern bool option_proof_merge;
extern bool proof_version;

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief resets DAG_tmp of all DAGs used during printing */
static void
proof_reset_DAG_tmp(Tproof_step proof_step)
{
  unsigned i, nb_bound_vars = 0;
  for (i = 0; i < stack_size(proof_step->DAGs); ++i)
    DAG_tmp_reset_unsigned(stack_get(proof_step->DAGs, i));
  if (proof_step->args)
    for (i = 0; i < stack_size(proof_step->args); ++i)
      DAG_tmp_reset_unsigned(stack_get(proof_step->args, i));
  if (proof_step->type < ps_type_subproof)
    return;
  for (i = 1; i < stack_size(proof_step->subproof_steps); ++i)
    proof_reset_DAG_tmp(stack_get(proof_step->subproof_steps, i));
  if (proof_step->args)
    {
      nb_bound_vars = stack_top(proof_step->args);
#ifdef DEBUG
      for (i = 0; i < nb_bound_vars; ++i)
        assert(!DAG_tmp_unsigned[stack_get(proof_step->args, i)]);
#endif
      for (i = nb_bound_vars; i < stack_size(proof_step->args) - 1u; i += 2)
        {
          assert(!DAG_tmp_unsigned[stack_get(proof_step->args, i)]);
          DAG_tmp_reset_unsigned(stack_get(proof_step->args, i + 1));
        }
    }
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief prints proof step (for outputting the proof and debugging purposes)
   \param proof_step the proof step
   \param id the proof step id
   \param file the file to write to */
void
proof_step_print_older(Tproof_step proof_step, Tstack_proof_step steps,
                       Tproof id, FILE * file)
{
  unsigned i;
  fprintf(file, "%d:(%s (", id, ps_type_desc[proof_step->type].name);
  if (proof_step->type >= ps_type_subproof)
    {
      fprintf(file, "\n");
      for (i = 1; i < stack_size(proof_step->subproof_steps); ++i)
        proof_step_print_older(stack_get(proof_step->subproof_steps, i),
                               proof_step->subproof_steps, i, file);
    }
  /* gen_clause */
  else
    for (i = 0; i < stack_size(proof_step->DAGs); ++i)
      {
        if (i) fprintf(file, " ");
        DAG_proof_print(file, stack_get(proof_step->DAGs, i));
      }
  fprintf(file, ")");
  if (proof_step->reasons)
    for (i = 0; i < stack_size(proof_step->reasons); ++i)
      fprintf(file, " %d", stack_get(proof_step->reasons, i));
  fprintf(file, ")\n");
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief prints proof step (for outputting the proof and debugging purposes)
   \param proof_step the proof step
   \param id the proof step id
   \param file the file to write to */
void
proof_step_print_old(Tproof_step proof_step, Tstack_proof_step steps,
                     Tproof id, FILE * file)
{
  unsigned i, nb_bound_vars;
  if (proof_step->type == ps_type_input)
    {
      if (stack_size(proof_step->DAGs) != 1)
        my_error("proof_step_print: internal error\n");
      /* [TODO] check this, looks weird */
      char ** Pname = DAG_prop_get(stack_get(proof_step->DAGs, 0), DAG_PROP_NAMED);
      Pname = DAG_prop_get(stack_get(proof_step->DAGs, 0), DAG_PROP_NAMED);
      if (Pname)
        return;
    }
  fprintf(file, "(set .c%d (%s ", id, ps_type_desc[proof_step->type].name);
  /* gen_clause */
  if (proof_step->reasons)
    {
      assert(!stack_is_empty(proof_step->reasons));
      fprintf(file, ":clauses (");
      for (i = 0; i < stack_size(proof_step->reasons); ++i)
        {
          assert(stack_get(proof_step->reasons, i) <= stack_size(steps));
          Tproof_step proof_step2 =
            stack_get(steps, stack_get(proof_step->reasons, i));
          if (proof_step2->type == ps_type_input)
            {
              char ** Pname;
              if (stack_size(proof_step2->DAGs) != 1)
                my_error("proof_step_print: internal error\n");
              Pname = DAG_prop_get(stack_get(proof_step2->DAGs, 0),
                                   DAG_PROP_NAMED);
              if (Pname)
                {
                  fprintf(file, i?" %s":"%s", *Pname);
                  continue;
                }
            }
          fprintf(file, i?" .c%d":".c%d", stack_get(proof_step->reasons, i));
        }
      fprintf(file, ") ");
    }
  if (proof_step->type >= ps_type_subproof)
    {
      if (proof_step->args)
        {
          fprintf(file, ":args (");
          nb_bound_vars = stack_top(proof_step->args);
          if (nb_bound_vars)
            {
              fprintf(file, "(");
              for (i = 0; i < nb_bound_vars; ++i)
                {
                  fprintf(file, "%s", i? " " : "");
                  DAG_proof_print(file, stack_get(proof_step->args, i));
                }
              fprintf(file, ")");
            }
          for (i = nb_bound_vars; i < stack_size(proof_step->args) - 1u; i += 2)
            {
              fprintf(file, "%s(:= ", i > nb_bound_vars? " " : "");
              DAG_proof_print(file, stack_get(proof_step->args, i));
              fprintf(file, " ");
              DAG_proof_print(file, stack_get(proof_step->args, i + 1));
              fprintf(file, ")");
            }
          fprintf(file, ")");
        }
      fprintf(file, "\n");
      for (i = 1; i < stack_size(proof_step->subproof_steps); ++i)
        proof_step_print_old(stack_get(proof_step->subproof_steps, i),
                             proof_step->subproof_steps, i, file);
    }
  else
    {
      if (proof_step->args)
        {
          assert(!stack_is_empty(proof_step->args));
          fprintf(file, ":args (");
          for (i = 0; i < stack_size(proof_step->args); ++i)
            {
              if (i) fprintf(file, " ");
              DAG_proof_print(file, stack_get(proof_step->args, i));
            }
          fprintf(file, ") ");
        }
    }
  /* fprintf(file, ":conclusion (%s", proof_step->type == ps_type_cong? "= " : ""); */
  fprintf(file, ":conclusion (");
  for (i = 0; i < stack_size(proof_step->DAGs); ++i)
    {
      if (i) fprintf(file, " ");
      DAG_proof_print(file, stack_get(proof_step->DAGs, i));
    }
  fprintf(file, ")"); /* conclusion */
  fprintf(file, ")"); /* gen_clause */
  fprintf(file, ")\n"); /* step */
}

/*--------------------------------------------------------------*/

void
proof_step_print(Tproof_step proof_step, Tstack_proof_step steps,
                 Tproof id, FILE * file)
{
  fprintf(file, "standard proof format not defined yet\n");
}

/*--------------------------------------------------------------*/

void
proof_out(FILE * file)
{
  unsigned i;
  if (option_proof_prune)
    {
      if (option_proof_merge)
        steps_merge();
      steps_prune();
    }
  if (proof_version == 2)
    for (i = 1; i < stack_size(top_steps); ++i)
      if (stack_get(top_steps, i)->type == ps_type_th_resolution)
        stack_get(top_steps, i)->type = ps_type_SAT_resolution;
  DAG_tmp_reserve();
  /* Collect choice functions */
  for (i = 0; i < stack_size(choices); ++i)
    DAG_tmp_unsigned[stack_get(choices, i).src] = stack_get(choices, i).dest;
  /* Collect ite csts */
  for (i = 0; i < stack_size(ite_csts); ++i)
    DAG_tmp_unsigned[stack_get(ite_csts, i).src] = stack_get(ite_csts, i).dest;
  /* Print steps */
  for (i = 1; i < stack_size(top_steps); ++i)
    if (proof_version == 2)
      proof_step_print_older(stack_get(top_steps, i), top_steps, i, file);
    else if (proof_version == 1)
      proof_step_print_old(stack_get(top_steps, i), top_steps, i, file);
    else
      proof_step_print(stack_get(top_steps, i), top_steps, i, file);
  for (i = 1; i < stack_size(top_steps); ++i)
    proof_reset_DAG_tmp(stack_get(top_steps, i));
  /* Clean for choice functions */
  for (i = 0; i < stack_size(choices); ++i)
    {
      assert(!DAG_tmp_unsigned[stack_get(choices, i).src]);
      DAG_tmp_reset_unsigned(stack_get(choices, i).dest);
    }
  /* Clean for ite csts */
  for (i = 0; i < stack_size(ite_csts); ++i)
    {
      /* [TODO] understand this asserts */
      DAG_tmp_reset_unsigned(stack_get(ite_csts, i).src);
      assert(!DAG_tmp_unsigned[stack_get(ite_csts, i).dest]);
    }
  DAG_tmp_release();
}
