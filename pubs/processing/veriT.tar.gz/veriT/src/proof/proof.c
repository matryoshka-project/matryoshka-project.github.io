/**
   \file proof.c
   \author Pascal Fontaine

   \brief proof module.

   This module provides API functions to memorize the proofs done in
   veriT.
*/

#include "config.h"

#ifdef PROOF

#include <string.h>

#include "general.h"
#include "options.h"
#include "statistics.h"

#include "bool.h"
#include "DAG.h"
#include "DAG-tmp.h"

#include "veriT-status.h"
#include "veriT-state.h"
#include "context-recursion-proof.h"

#include "proof-id.h"
#include "proof.h"

/* #define DEBUG_PROOF */

bool proof_on = false;

int proof_version;
char * option_proof_filename = NULL;
bool proof_no_replacement = false;
bool print_open = false;
bool proof_with_sharing = false;
bool option_proof_prune = false;
bool option_proof_merge = false;

/**
   \addtogroup arguments_developer
   - --print-proof-file-from-input
   Set proof output file name from input file name by adding .proof */
bool option_proof_file_from_input;
/**
   \addtogroup arguments_developer
   - --proof-stats
   Output proof statistics (incompatible with actual proof output) */
bool proof_stats = false;

/*
  --------------------------------------------------------------
  Documentation
  --------------------------------------------------------------
*/

void
proof_doc(FILE * file)
{
  int i;
  fprintf(file, "The proof format is a sequence of lines\n"
          "    n:(type clause clause_ids params)\nwhere\n"
          " - n is a number (starting from 1).  It is the identifier of the deduced clause\n"
          " - type is a deduction type\n"
          " - clause is a list (L1 ... Lm) of the literals in the clause\n"
          " - clause_ids is a (possibly empty) sequence of clause identifiers\n"
          " - params is a (possibly empty) sequence of integers.\n"
          "   The number of those (clause_ids and params) arguments depend on the type\n"
          "The following types are currently output\n");

  for (i = 1; i < PS_TYPE_MAX; i++)
    fprintf(file, " * %-17s : %s\n",
            ps_type_desc[i].name, ps_type_desc[i].descr);

  fprintf(file, "The following deduction types require exactly one clause_id argument:\n");
  for (i = 1; i < PS_TYPE_MAX; i++)
    if (ps_type_desc[i].nb_reasons == 1)
      fprintf(file, " * %-17s\n", ps_type_desc[i].name);
  fprintf(file, "The following deduction types may have any number of clause_id arguments:\n");
  for (i = 1; i < PS_TYPE_MAX; i++)
    if (ps_type_desc[i].nb_reasons == -1)
      fprintf(file, " * %-17s\n", ps_type_desc[i].name);
  fprintf(file, "The following deduction types require exactly one integer parameter:\n");
  for (i = 1; i < PS_TYPE_MAX; i++)
    if (ps_type_desc[i].nb_params == 1)
      fprintf(file, " * %-17s\n", ps_type_desc[i].name);

  fprintf(file, "\n");
  fprintf(file, "Please notice that\n"
          " - double negations are silently simplified\n"
          " - clauses are silently simplified to eliminate repeated"
          " literals\n"
          " - clauses with complementary literals are silently simplified"
          " to true\n"
          " - symmetry and reflexivity of equality is silently used\n\n");

  fprintf(file, "Currently, QF_UF/QF_IDL/QF_RDL/QF_UFIDL are covered"
          " by proof production.\n");
  fprintf(file, "Also notice that the fragments using difference logic (DL) "
          "may require\npreprocessing steps that are not proof producing.\n"
          "Formulas with quantifiers also require preprocessing steps\n"
          "that are not proof-producing.\n"
          "Skolemization is proof producing though.\n"
          "The user is responsible for providing an adequately written formula.\n\n");

  fprintf(file, "Option --proof-with-sharing uses DAG sharing in the"
          " output proof.\n"
          "Every first occurrence of a term or formula (except negations and"
          " 0-ary terms and formulas)\n"
          "is written as #n:term, where n is its identifier.  Every later occurrence"
          " is simply #n\n");
  fprintf(file, "Option --proof-prune eliminates every unused step in the proof.\n\n");

  fprintf(file, "The following features will be implemented in the future:\n"
          " - Eliminate similar deductions\n"
          " - Output proof for full linear arithmetics\n"
          " - Output proof for E-prover inferences (maybe?)\n");
  fprintf(file, "The following features may be implemented if requested:\n"
          " - Eliminate redundancy in the proof format\n"
          " - Transform n-ary resolution to binary resolution\n"
          " - Make symmetry, reflexivity of equality explicit\n"
          " - Make double negation simplification explicit\n");
}

/*
  --------------------------------------------------------------
  Statistics
  --------------------------------------------------------------
*/

static unsigned
proof_size(void)
{
  unsigned i;
  unsigned size = 0;
  for (i = 1; i < stack_size(top_steps); ++i)
    size += stack_size(stack_get(top_steps, i)->DAGs);
  return size;
}

/*--------------------------------------------------------------*/

static unsigned
proof_length(void)
{
  return stack_size(top_steps);
}

/*--------------------------------------------------------------*/

static void
proof_stat_compute(void)
{
  unsigned stat_proof_time;
  unsigned stat_proof_length;
  unsigned stat_proof_size;
  unsigned stat_proof_length_pruned;
  unsigned stat_proof_size_pruned;
  unsigned stat_proof_length_merged;
  unsigned stat_proof_size_merged;
  stat_proof_time =
    stats_timer_new("proof_time", "Time to compute proof stats", "%7.2f",
                    STATS_TIMER_ALL);
  stat_proof_length =
    stats_counter_new("proof_length", "Number of proof steps", "%7d");
  stat_proof_size =
    stats_counter_new("proof_size", "Number of literals in proof", "%7d");
  stat_proof_length_pruned =
    stats_counter_new("proof_length_pruned", "Number of proof steps (pruned)",
                      "%7d");
  stat_proof_size_pruned =
    stats_counter_new("proof_size_pruned",
                      "Number of literals in proof (pruned)", "%7d");
  stat_proof_length_merged =
    stats_counter_new("proof_length_merged",
                      "Number of proof steps (merged)", "%7d");
  stat_proof_size_merged =
    stats_counter_new("proof_size_merged",
                      "Number of literals in proof (merged)", "%7d");
  stats_timer_start(stat_proof_time);
  stats_counter_set(stat_proof_length, (int) proof_length());
  stats_counter_set(stat_proof_size, (int) proof_size());
  steps_prune();
  stats_counter_set(stat_proof_length_pruned, (int) proof_length());
  stats_counter_set(stat_proof_size_pruned, (int) proof_size());
  steps_merge();
  steps_prune();
  stats_counter_set(stat_proof_length_merged, (int) proof_length());
  stats_counter_set(stat_proof_size_merged, (int) proof_size());
  stats_timer_stop(stat_proof_time);
}

/*
  --------------------------------------------------------------
  Init/Done
  --------------------------------------------------------------
*/

void
proof_init(void)
{
  proof_status = OPEN;

  options_new_string(0, "proof",
                     "Sets a file name to output proof (- for stdout)",
                     "filename",
                     &option_proof_filename);
  options_new_int(0, "proof-version",
                  "Proof format version", "(0|1|2)",
                  &proof_version);
  proof_version = 1;
  options_new(0, "proof-open",
              "Print open proof",
              &print_open);
  options_new(0, "proof-no-replacement",
              "Uses congruence and resolution instead of shallow replacements",
              &proof_no_replacement);
  options_new(0, "proof-with-sharing",
              "Use sharing in the output proof",
              &proof_with_sharing);
  options_new(0, "proof-prune",
              "Prune the proof of unused deduction",
              &option_proof_prune);
  options_new(0, "proof-merge",
              "Merge identical clauses in the proof",
              &option_proof_merge);
  options_new (0, "proof-file-from-input",
               "Use filename+.proof as output file",
               &option_proof_file_from_input);
  /* TODO make proof stat compatible with proof output */
  options_new (0, "proof-stats",
               "Output proof statistics (incompatible with actual proof output)",
               &proof_stats);
  steps_init();
  proof_SAT_init();
  proof_lemma_init();
}

/*--------------------------------------------------------------*/

static char * input_filename = NULL;

void
proof_set_input_file(char * filename)
{
  input_filename = strmake(filename);
}

/*--------------------------------------------------------------*/

void
proof_done(void)
{
  if (proof_on && proof_status == OPEN && !print_open)
    my_warning("proof_done: status is still open\n");
  proof_lemma_done();
  proof_SAT_done();
  if (proof_on && option_proof_file_from_input && input_filename)
    {
      free(option_proof_filename);
      MY_MALLOC(option_proof_filename, strlen(input_filename) + 6 + 1);
      strcpy(option_proof_filename, input_filename);
      strcat(option_proof_filename, ".proof");
    }
  if (proof_on &&
      proof_stats &&
      !option_proof_filename &&
      !option_proof_file_from_input &&
      proof_status == UNSAT)
    proof_stat_compute();
  else if (proof_on && option_proof_filename)
    {
      FILE * file = stdout;
      if (strcmp(option_proof_filename, "-"))
        if (!(file = fopen(option_proof_filename, "w")))
          {
            my_warning("Unable to open proof file %s\n", option_proof_filename);
            file = stdout;
          }
      if (proof_status == SAT)
        {
          fprintf(file, "Formula is Satisfiable\n");
          if (print_open)
            proof_out(file);
        }
      else if (proof_status == UNSAT || print_open)
        proof_out(file);
      if (strcmp(option_proof_filename, "-"))
        fclose(file);
    }
  steps_done();
  free(input_filename);
}

#else

#ifdef PEDANTIC

#include "proof.h"

void
proof_done(void)
{
}
#endif

#endif /* PROOF */
