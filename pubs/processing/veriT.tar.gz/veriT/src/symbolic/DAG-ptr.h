/*
  --------------------------------------------------------------
  Obsolete functions about DAG and pointers
  --------------------------------------------------------------
*/

#ifndef DAG_PTR_H
#define DAG_PTR_H

#define DAG_of_ptr(P) ((TDAG) (uintptr_t) (P))
#define DAG_ptr_of(P) ((void *) (uintptr_t) (P))

#endif
