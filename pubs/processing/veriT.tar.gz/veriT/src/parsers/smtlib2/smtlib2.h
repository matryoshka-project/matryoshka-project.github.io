#ifndef SMTLIB2_H
#define SMTLIB2_H

#include <stdio.h>

void      parse_smtlib2 (FILE * file, bool option_disable_print_success);

#endif
