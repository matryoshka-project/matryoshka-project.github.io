#include <string.h>

#include "config.h"

#include "general.h"

#include "DAG.h"
#include "DAG-stat.h"
#include "options.h"

#ifdef DEBUG
#include "DAG-print.h"
#endif

#include "DAG-symb-DAG.h"
#include "fix-trigger.h"
#include "HOL.h"
#include "binder-rename.h"
#include "bfun-elim.h"
#include "bclauses.h"
#include "distinct-elim.h"
#include "ite-elim.h"
#include "free-vars.h"
#include "inst-pre.h"
#include "inst-trigger.h"
#include "nary-elim.h"
#include "pm.h"
#include "pre.h"
#include "qnt-tidy-old.h"
#include "qnt-tidy.h"
#include "qnt-utils.h"
#include "qnt-trigger.h"
#include "rare-symb.h"
#include "simplify-old.h"
#include "simplify.h"
#include "recursion.h"
#include "context-recursion.h"
#include "context-recursion-proof.h"
#include "skolem-old.h"
#include "skolem.h"
#include "connectives.h"
#include "let-elim.h"
#include "simp-sym.h"
#include "simp-unit.h"
#include "proof.h"
#include "LA-pre.h"

static bool pre_quantifier = true;
static bool pre_eq = false;

static bool disable_ctx = false;

/**
   \addtogroup arguments_user

   - --disable-simp

   Disables simplification of expressions. */
static bool disable_simp = false;

static bool disable_unit_simp = false;
static bool disable_unit_subst_simp = false;
static bool disable_bclause = false;
static bool disable_ackermann = false;

/**
   \addtogroup arguments_user

   - --disable-sym

   Disables symmetry breaking. */
static bool disable_sym = false;

/**
   \addtogroup arguments_user

   - --enable-assumption-simp

   Enables application of simplifications of assumptions */
static bool enable_assumption_simp = 0;

bool enable_nnf_simp = false;

/*--------------------------------------------------------------*/

#ifdef PROOF

Tstack_DAG snapshot = NULL;

static void
pre_proof_snapshot(unsigned n, TDAG * Psrc)
{
  unsigned i;
  if (!snapshot)
    {
      stack_INIT(snapshot);
    }
  else
    for (i = 0; i < stack_size(snapshot); i++)
      DAG_free(stack_get(snapshot,i));
  stack_resize(snapshot, n);
  for (i = 0; i < n; i++)
    stack_set(snapshot, i, DAG_dup(Psrc[i]));
}

/*--------------------------------------------------------------*/

static void
pre_proof_compare(unsigned n, TDAG * Psrc, Tproof * Pproof,
                  Tproof (f) (Tproof, TDAG))
{
  unsigned i;
  assert (stack_size(snapshot) == n);
  for (i = 0; i < n; i++)
    if (Psrc[i] != stack_get(snapshot, i))
      Pproof[i] = f(Pproof[i], Psrc[i]);
}

/*--------------------------------------------------------------*/

static void
pre_proof_erase_snapshot(void)
{
  unsigned i;
  if (snapshot)
    for (i = 0; i < stack_size(snapshot); i++)
      DAG_free(stack_get(snapshot,i));
  stack_free(snapshot);
}
#endif

/*--------------------------------------------------------------*/

static TDAG
pre_HOL_to_FOL(TDAG src)
{
  TDAG dest;
  /**************** fix_triggers */
  /* DD normalizes triggers (quantification patterns)
     this should be done once and forall on every input formula
     instances should not be reprocessed */
  /* In principle this should also be applied on formulas coming from
     macros, etc.  However, since this is a favour for the user who
     writes badly formed formulas, it will not be applied on macros */
  fix_trigger_array(1, &src);

  /**************** macro_subst */
  /* PF HOL->FOL: the higher order processing */
  /* binder_rename is applied on macro body before expansion so that
     - no bound variable of the macro interacts with bound/unbound vars
     of the formula
     - no free symbol of the macro interacts with binders of the formulas
     thanks to the fact that binder_rename uses fresh names
     To avoid problems with macro containing macros, this occurs
     at macro expansion in macro_substitute */
  /* requires the binder_rename invariant
     should come high in the list because it will introduce new terms
     that also need processing */
  if (!disable_ctx)
    {
      /* dest = context_structural_recursion(src, let_elim_init, let_elim_push, */
      /*                                     let_elim_pop, let_elim_reduce, NULL); */
      dest = let_context_structural_recursion(src, let_elim_init, let_elim_push,
                                              let_elim_pop, let_elim_reduce);
      DAG_free(src);
      src = dest;
      /* DAG_symb_DAG_check(); */
    }
  else
    {
      dest = HOL_to_FOL(src);
      DAG_free(src);
      src = dest;
    }
  /**************** bfun_elim */
  dest = bfun_elim(src);
  DAG_free(src);
  src = dest;
  /* my_DAG_message("HOL_to_FOL %D\n", src); */
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static void
pre_HOL_to_FOL_array_proof(unsigned n, TDAG * Psrc, Tproof * Pproof)
{
  unsigned i;
  TDAG dest;
  /**************** fix_triggers */
  /* DD normalizes triggers (quantification patterns)
     this should be done once and forall on every input formula
     instances should not be reprocessed */
  /* In principle this should also be applied on formulas coming from
     macros, etc.  However, since this is a favour for the user who
     writes badly formed formulas, it will not be applied on macros */
  fix_trigger_array(n, Psrc);
  /**************** HOL_to_FOL */
  /* PF HOL->FOL: the higher order processing */
  /* binder_rename is applied on macro body before expansion so that
     - no bound variable of the macro interacts with bound/unbound vars
     of the formula
     - no free symbol of the macro interacts with binders of the formulas
     thanks to the fact that binder_rename uses fresh names
     To avoid problems with macro containing macros, this occurs
     at macro expansion in macro_substitute */
  if (!disable_ctx)
    {
      /**************** let elimination */
      /* context_structural_recursion_array_proof(n, Psrc, Pproof, let_elim_ctx_aux_proof, CTX_NONE); */
      for (i = 0; i < n; ++i)
        {
          dest = context_structural_recursion_proof(Psrc[i], &Pproof[i],
                                                    let_elim_init_proof,
                                                    let_elim_push_proof,
                                                    let_elim_pop_proof,
                                                    let_elim_replacement,
                                                    let_elim_reduce_proof, NULL);
          DAG_symb_DAG_check();
          DAG_free(Psrc[i]);
          Psrc[i] = dest;
        }
    }
  else
    {
      /**************** beta_reduction */
      /* should come after equality lowering because it could rewrite
         X = lambda x. f(x) to forall y . X(y) = ((lambda x . f(x)) y) */
      pre_proof_snapshot(n, Psrc);
      HOL_to_FOL_array(n, Psrc);
      DAG_symb_DAG_check();
      pre_proof_compare(n, Psrc, Pproof, proof_tmp_betared);
    }
  /* HOL-free, let-free below this point, but still bfuns */
  /**************** bfun_elim */
  pre_proof_snapshot(n, Psrc);
  bfun_elim_array(n, Psrc);
  pre_proof_compare(n, Psrc, Pproof, proof_tmp_bfun_elim);
  pre_proof_erase_snapshot();
}

#endif

/*--------------------------------------------------------------*/

static TDAG
distinct_elim_aux(TDAG src)
{
  unsigned i, j, k = 0;
  TDAG dest, *PDAG;
  if (DAG_symb(src) != PREDICATE_DISTINCT)
    return src;
  if (DAG_arity(src) <= 1)
    {
      DAG_free(src);
      return DAG_dup(DAG_TRUE);
    }
  if (DAG_sort(DAG_arg(src, 0)) == SORT_BOOLEAN)
    {
      dest = DAG_dup(DAG_arity(src) > 2 ? DAG_FALSE :
                     DAG_not(DAG_equiv(DAG_arg0(src), DAG_arg1(src))));
      DAG_free(src);
      return dest;
    }
  if (DAG_arity(src) == 2)
    {
      dest = DAG_dup(DAG_neq(DAG_arg0(src), DAG_arg1(src)));
      DAG_free(src);
      return dest;
    }
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  memcpy(PDAG, DAG_args(src), DAG_arity(src) * sizeof(TDAG));
  simp_sym_notify(DAG_arity(src), PDAG);
  MY_MALLOC(PDAG, DAG_arity(src) * (DAG_arity(src) - 1) * sizeof(TDAG) / 2);
  for (i = 0; i < DAG_arity(src); i++)
    for (j = i + 1; j < DAG_arity(src); j++)
      PDAG[k++] = DAG_neq(DAG_arg(src, i), DAG_arg(src, j));
  dest = DAG_dup(DAG_new(CONNECTOR_AND, DAG_arity(src) * (DAG_arity(src) - 1) / 2,
                         PDAG));
  DAG_free(src);
  return dest;
}

#ifdef DEBUG
void
eq_norm_rec(TDAG src)
{
  if (DAG_symb(src) == PREDICATE_EQ &&
      (DAG_sort(DAG_arg0(src)) == SORT_BOOLEAN ||
       DAG_sort(DAG_arg1(src)) == SORT_BOOLEAN))
    my_error("equality over propositions found\n");
}
#endif

static TDAG
pre_lang_red(TDAG src)
{
  TDAG dest;
#ifdef DEBUG
  /* Check if there are equalities between propositions */
  structural_recursion_void(src, eq_norm_rec);
#endif
  if (!disable_ctx)
    {
      dest = nosub_context_structural_recursion(src, nary_elim_node_init,
                                          nary_elim_node_push, nary_elim_node_pop,
                                          nary_elim_node_reduce, NULL);
      DAG_free(src);
      src = dest;
      dest = nosub_context_structural_recursion(src, distinct_elim_init,
                                          distinct_elim_push, distinct_elim_pop,
                                          distinct_elim_reduce, NULL);
      DAG_free(src);
    }
  else
    {
      /**************** nary_elim */
      /* replace n-ary by binary operators necessary for Skolemization */
      dest = structural_recursion(src, nary_elim_node);
      DAG_free(src);
      src = dest;
      /**************** distinct_elim */
      dest = structural_recursion(src, distinct_elim_aux);
      DAG_free(src);
    }
  return dest;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static TDAG
pre_lang_red_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
#ifdef DEBUG
  /* Check if there are equalities between propositions */
  structural_recursion_void(src, eq_norm_rec);
#endif
  /**************** nary_elim */
  /* replace n-ary by binary operators necessary for Skolemization */
  dest =
    context_structural_recursion_proof(src, Pproof,
                                       nary_elim_node_init,
                                       nary_elim_node_push_proof,
                                       nary_elim_node_pop,
                                       nary_elim_node_replacement,
                                       nary_elim_node_reduce_proof, NULL);
  DAG_free(src);
  src = dest;
  /**************** distinct_elim */
  dest =
    context_structural_recursion_proof(src, Pproof,
                                       distinct_elim_init,
                                       distinct_elim_push_proof,
                                       distinct_elim_pop,
                                       distinct_elim_replacement,
                                       distinct_elim_reduce_proof, NULL);
  DAG_free(src);
  return dest;
}

#endif /* PROOF */

/*--------------------------------------------------------------*/

#include "inst-pre.h"

/* [TODO] add a simplification to simplify AxAyAx => AyAx; AxEyAx =>
   EyAx. Renaming will probably mess this up, so it should be done before it. */

/**
   \brief joins sequential quantifiers of same type, removes unused variables,
   canonizes variables */
static TDAG
pre_quant_static(TDAG src)
{
  TDAG dest;
  if (!DAG_quant(src))
    return DAG_dup(src);
  if (!disable_ctx)
    {  /* Whether there are free or reused variables */
      check_free_shadowed_vars(src);
      DAG_symb_var_resize(stack_size(DAG_sort_stack));

      dest = context_structural_recursion(src, qnt_join_init,
                                          qnt_join_push, qnt_join_pop,
                                          qnt_join_reduce,
                                          DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Remove variables which are not used */
      dest = context_structural_recursion(src, qnt_rm_unused_init,
                                          qnt_rm_unused_push, qnt_rm_unused_pop,
                                          qnt_rm_unused_reduce,
                                          DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Structurally identical formulas are canonized to have the same vars */
      dest = context_structural_recursion(src, qnt_canon_init,
                                          qnt_canon_push, qnt_canon_pop,
                                          qnt_canon_reduce,
                                          DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* [TODO] this really needs to be done again? */
      dest = context_structural_recursion(src, qnt_join_init,
                                          qnt_join_push, qnt_join_pop,
                                          qnt_join_reduce,
                                          DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Completely breaks the binder_rename invariant */
      dest = context_structural_recursion(src, qnt_simp_init,
                                          qnt_simp_push, qnt_simp_pop,
                                          qnt_simp_reduce,
                                          DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
    }
  else
    {
      dest = qnt_tidy(src);
      DAG_free(src);
      src = dest;
      /* Completely breaks the binder_rename invariant */
      /* Skolemization does not go into ite terms
         This should thus be applied after ite elimination */
      dest = qnt_simplify(src);
      DAG_free(src);
      src = dest;
    }
  return src;
}

/*--------------------------------------------------------------*/

static TDAG
pre_quant_ite(TDAG src)
{
  TDAG dest;
  int first = 1, changed = 0;
  /* here is a loop to eliminate skolem quant and ites */
  do
    {
      if (!disable_simp)
        {
          if (!disable_ctx)
            src = simplify_formula(src);
          else
            src = simplify_formula_old(src);
        }
      dest = ite_elim(src);
      /* ite elim may reveal new skolemizable quant */
      if (!first && src == dest)
        {
          DAG_free(dest);
          break;
        }
      else
        first = 0;
      DAG_free(src);
      src = dest;
      if (!disable_ctx)
        {
          /* remove double pol connectives over subformulas with quantifiers */
          dest = nosub_context_structural_recursion(src, single_pol_qnt_init,
                                                    single_pol_qnt_push,
                                                    single_pol_qnt_pop,
                                                    single_pol_qnt_reduce,
                                                    DAG_quant_f);
          check_free_shadowed_vars(src);
          changed = (src != dest);
          DAG_free(src);
          src = dest;
          /* skolemization, which may make new ite terms appear and, if deep_SKO is
             on, joinable quantifiers */
          dest = skolemize(src);
          changed = changed || (src != dest);
          DAG_free(src);
          src = dest;
          /* get rid of weak existentials */
          dest = context_structural_recursion(src, rewrite_w_exist_init,
                                              rewrite_w_exist_push,
                                              rewrite_w_exist_pop,
                                              rewrite_w_exist_reduce,
                                              rewrite_w_exist_cont);
        }
      else
        dest = skolemize_old(src);
      changed = changed || (src != dest);
      DAG_free(src);
      src = dest;
    }
  while (changed);
  if (enable_nnf_simp)
    {
      /* Remove conectives besides AND/OR/NOT from scope of quantifiers */
      dest = qnt_connectives(src);
      changed = changed || (src != dest);
      DAG_free(src);
      src = dest;
      if (!disable_simp && changed)
        {
          if (!disable_ctx)
            src = simplify_formula(src);
          else
            src = simplify_formula_old(src);
          changed = false;
        }
      /* Put quantified formulas in NNF, remove weak existentials */
      dest = qnt_NNF(src);
      changed = changed || (src != dest);
      DAG_free(src);
      src = dest;
      if (!disable_simp && changed)
        {
          if (!disable_ctx)
            src = simplify_formula(src);
          else
            src = simplify_formula_old(src);
          changed = false;
        }
      dest = qnt_uniq_vars(src);
      if (!disable_simp && src != dest)
        {
          if (!disable_ctx)
            src = simplify_formula(src);
          else
            src = simplify_formula_old(src);
        }
      DAG_free(src);
      src = dest;
      /* dest = qnt_NF(src); */
      /* DAG_free(src); */
      /* src = dest; */
    }
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

/**
   \brief joins sequential quantifiers of same type, removes unused variables,
   canonizes variables */
static TDAG
pre_quant_static_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
  if (!DAG_quant(src))
    return DAG_dup(src);
  if (!disable_ctx)
    {
      /* Whether there are free or reused variables */
      check_free_shadowed_vars(src);
      DAG_symb_var_resize(stack_size(DAG_sort_stack));

      dest = context_structural_recursion_proof(src, Pproof,
                                                qnt_join_init, qnt_join_push_proof,
                                                qnt_join_pop, qnt_join_replacement,
                                                qnt_join_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Remove variables which are not used */
      dest = context_structural_recursion_proof(src, Pproof, qnt_rm_unused_init,
                                                qnt_rm_unused_push_proof,
                                                qnt_rm_unused_pop,
                                                qnt_rm_unused_replacement,
                                                qnt_rm_unused_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Structurally identical formulas are canonized to have the same vars */
      dest = context_structural_recursion_proof(src, Pproof,
                                                qnt_canon_init,
                                                qnt_canon_push_proof, qnt_canon_pop,
                                                qnt_canon_replacement,
                                                qnt_canon_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* [TODO] this really needs to be done again? */
      dest = context_structural_recursion_proof(src, Pproof,
                                                qnt_join_init, qnt_join_push_proof,
                                                qnt_join_pop, qnt_join_replacement,
                                                qnt_join_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Completely breaks the binder_rename invariant */
      dest = context_structural_recursion_proof(src, Pproof, qnt_simp_init,
                                                qnt_simp_push_proof, qnt_simp_pop,
                                                qnt_simp_replacement,
                                                qnt_simp_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_symb_DAG_check();
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
    }
  else
    {
      dest = qnt_tidy(src);
      if (src != dest)
        *Pproof = proof_tmp_qnt_tidy(*Pproof, dest);
      DAG_free(src);
      src = dest;
      /* Completely breaks the binder_rename invariant */
      /* Skolemization does not go into ite terms
         This should thus be applied after ite elimination */
      dest = qnt_simplify(src);
      if (src != dest)
        *Pproof = proof_tmp_qnt_simplify(*Pproof, dest);
      DAG_free(src);
      src = dest;
    }
  return src;
}

/*--------------------------------------------------------------*/

static TDAG
pre_quant_ite_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
  int first = 1, changed = 0;
  do
    {
      if (!disable_simp && !disable_ctx)
        src = simplify_formula_proof(src, Pproof);
      dest = ite_elim(src);
      /* ite elim may reveal new skolemizable quant */
      if (src != dest)
        *Pproof = proof_ite_intro(src, dest, *Pproof);
      if (!first && src == dest)
        {
          DAG_free(dest);
          break;
        }
      else
        first = 0;
      DAG_free(src);
      src = dest;
      if (!disable_ctx)
        {
          /* double pol connectives */
          dest = context_structural_recursion_proof(src, Pproof,
                                                    single_pol_qnt_init,
                                                    single_pol_qnt_push_proof,
                                                    single_pol_qnt_pop,
                                                    single_pol_qnt_replacement,
                                                    single_pol_qnt_reduce_proof,
                                                    DAG_quant_f);
          changed = (src != dest);
          DAG_free(src);
          src = dest;
          /* skolemization, which may make new ite terms appear and, if deep_SKO is
             on, joinable quantifiers */
          dest = skolemize_proof(src, Pproof);
          /* skolemize may make new ite terms appear */
          changed = changed || (src != dest);
          DAG_free(src);
          src = dest;
          /* get rid of weak existentials */
          dest = context_structural_recursion_proof(src, Pproof,
                                                    rewrite_w_exist_init,
                                                    rewrite_w_exist_push_proof,
                                                    rewrite_w_exist_pop,
                                                    rewrite_w_exist_replacement,
                                                    rewrite_w_exist_reduce_proof,
                                                    rewrite_w_exist_cont);
        }
      else
        {
          dest = skolemize_old(src);
          if (src != dest)
            *Pproof = proof_tmp_skolemize(*Pproof, dest);
        }
      changed = changed || (src != dest);
      DAG_free(src);
      src = dest;
    }
  while (changed);
  return src;
}

#endif

/*--------------------------------------------------------------*/

static TDAG
pre_ite(TDAG src)
{
  TDAG dest;
  /* simplify formula may handle ite in a more gentle way than
     ite_elim, it should therefore come before */
  if (!disable_simp)
    {
      if (!disable_ctx)
        src = simplify_formula(src);
      else
        src = simplify_formula_old(src);
    }
  /* This has no effect inside quantifiers
     This thus should be applied after any rewrite rule that may
     eliminate quantifiers */
  dest = ite_elim(src);
  DAG_free(src);
  src = dest;
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static TDAG
pre_ite_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
  /* simplify formula may handle ite in a more gentle way than
     ite_elim, it should therefore come before */
  if (!disable_simp && !disable_ctx)
    src = simplify_formula_proof(src, Pproof);
  /* This has no effect inside quantifiers
     This thus should be applied after any rewrite rule that may
     eliminate quantifiers */
  dest = ite_elim(src);
  if (src != dest)
    *Pproof = proof_ite_intro(src, dest, *Pproof);
    /* *Pproof = proof_tmp_ite_elim(*Pproof, dest); */
  DAG_free(src);
  src = dest;
  return src;
}

#endif

/*--------------------------------------------------------------*/

static TDAG
pre_non_essential(TDAG src)
{
  TDAG dest;
  if (!disable_ackermann)
    {
      dest = rare_symb(src);
      DAG_free(src);
      src = dest;
    }
  if (!disable_sym)
    {
      dest = simp_sym(src);
      DAG_free(src);
      src = dest;
    }
  if (!disable_unit_subst_simp)
    src = simplify_formula_sat(src);
  return src;
}

/*--------------------------------------------------------------*/

/* This uses NO, CC, etc..., and will only replace atoms by TRUE/FALSE
   this should come late */
/* Requires to have free access to the NO stack */
/* TODO: for incrementality, it should only be activated if the NO stack is empty */
static TDAG
pre_unit(TDAG src)
{
  TDAG dest;
  Tunsigned orig_n;
  Tunsigned dest_n = DAG_count_nodes(src);
  do
    {
      dest = simplify_unit(src);
      if (dest == src)
        {
          DAG_free(dest);
          break;
        }
      DAG_free(src);
      src = dest;
      {
        if (!disable_ctx)
          src = simplify_formula(src);
        else
          src = simplify_formula_old(src);
      }
      orig_n = dest_n;
      dest_n = DAG_count_nodes(src);
      check_free_shadowed_vars(src);
    }
  while ((dest_n > 1) && /* final formula is not TRUE or FALSE */
         /* previous decrease at least 10 % of nodes */
         ((orig_n - dest_n) * 10 > orig_n) &&
         /* previous decrease of at least 20 nodes */
         ((orig_n - dest_n) > 20));

  return src;
}

/*--------------------------------------------------------------*/

TDAG
pre_process(TDAG src)
{
  TDAG dest;
  src = pre_HOL_to_FOL(src);
  assert(is_FOL_strict(src));
  /* HOL-free, let-free below this point */
  src = pre_lang_red(src);
  /* HOL-free, let-free, symbol-normalized below this point */
  /* [TODO] Fix this, it's messy now because deep sko rearrange quantifiers,
     makes the static simplifications necessary again. */
  /* quantifier handling (skolem, tidy, simplify) is sensitive to HOL
     it should come after HOL elimination */
  if (pre_quantifier && DAG_quant(src))
    src = pre_quant_ite(pre_quant_static(src));
  else
    src = pre_ite(src);

  src = pre_non_essential(src);
  if (!disable_simp)
    {
      if (!disable_ctx)
        src = simplify_formula(src);
      else
        src = simplify_formula_old(src);
    }
  /* HB sets variables infrastructure; ground info is used in congruence
     closure, and quantifier handling, so this should come before unit
     simplification */
  if (pre_quantifier)
    set_fvars(src);

  if (!disable_unit_simp)
    src = pre_unit(src);

  if (!disable_bclause)
    {
      dest = bclauses_add(src);
      DAG_free(src);
      src = dest;
      {
        if (!disable_ctx)
          src = simplify_formula(src);
        else
          src = simplify_formula_old(src);
      }
      check_free_shadowed_vars(src);
    }
  /* PF this should come late because = may be used or generated before,
     e.g. for ite terms */
  if (pre_eq)
    {
      dest = context_structural_recursion(src, rewrite_eq_init,
                                          rewrite_eq_push, rewrite_eq_pop,
                                          rewrite_eq_reduce, NULL);
      DAG_free(src);
      src = dest;
    }
  /* HOL-free
     let-free
     symbol-normalized i.e. variety of symbols are rewritten (or n-ary
     to binary) so that no attention to those is necessary in the solver
     qnt_ground should be applied
     qnt_tidy should be applied
     ite should only occur in quantified formulas
     no strong (skolemizable) quantifier outside ite terms */
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

extern unsigned ctx_nb;

void
pre_process_array_proof(unsigned n, TDAG * Psrc, Tproof * Pproof)
{
  unsigned i;
  pre_HOL_to_FOL_array_proof(n, Psrc, Pproof);
  for (i = 0; i < n; ++i)
    assert(is_FOL_strict(Psrc[i]));
  /* HOL-free, let-free below this point */
  for (i = 0; i < n; i++)
    Psrc[i] = pre_lang_red_proof(Psrc[i], &Pproof[i]);
  /* HOL-free, let-free, symbol-normalized below this point */

  /* [TODO] Fix this, it's messy now because deep sko rearrange quantifiers,
     makes the static simplifications necessary again. */
  /* quantifier handling (skolem, tidy, simplify) is sensitive to HOL
     it should come after HOL elimination */
  for (i = 0; i < n; ++i)
    if (pre_quantifier && DAG_quant(Psrc[i]))
      {
        Psrc[i] = pre_quant_static_proof(Psrc[i], &Pproof[i]);
        Psrc[i] = pre_quant_ite_proof(Psrc[i], &Pproof[i]);
      }
    else
      Psrc[i] = pre_ite_proof(Psrc[i], &Pproof[i]);
  if (!disable_simp && !disable_ctx)
    for (i = 0; i < n; ++i)
      Psrc[i] = simplify_formula_proof(Psrc[i], &Pproof[i]);
  /* this should come very last because it only tags formulas
     ground bit is used in congruence closure, and quantifier handling,
     so this should come before unit simplification */
#ifndef PROOF
  /* IMPROVE */
  src = pre_non_essential(src);
#endif
  /* HB sets variables infrastructure */
  if (pre_quantifier)
    for (i = 0; i < n; ++i)
      if (DAG_quant(Psrc[i]))
        set_fvars(Psrc[i]);
#ifndef PROOF
  /* IMPROVE */
  if (!disable_unit_simp)
    src = pre_unit(src);

  if (!disable_bclause)
    {
      TDAG dest = bclauses_add(src);
      DAG_free(src);
      src = dest;
      src = simplify_formula(src);
      check_free_shadowed_vars(src);
    }
#endif
  /* PF this should come late because = may be used or generated before,
     e.g. for ite terms */
  /* PF this should come late because = may be used or generated before,
     e.g. for ite terms */
  if (pre_eq)
    /* context_structural_recursion_array_proof(n, Psrc, Pproof, let_elim_ctx_aux_proof, CTX_NONE); */
    for (i = 0; i < n; ++i)
      {
        TDAG dest = context_structural_recursion_proof(Psrc[i], &Pproof[i],
                                                       rewrite_eq_init,
                                                       rewrite_eq_push_proof,
                                                       rewrite_eq_pop,
                                                       rewrite_eq_replacement,
                                                       rewrite_eq_reduce_proof, NULL);
        DAG_symb_DAG_check();
        DAG_free(Psrc[i]);
        Psrc[i] = dest;
      }
  /* HOL-free
     let-free
     symbol-normalized i.e. variety of symbols are rewritten (or n-ary
     to binary) so that no attention to those is necessary in the solver
     qnt_ground should be applied
     qnt_tidy should be applied
     ite should only occur in quantified formulas
     no strong (skolemizable) quantifier outside ite terms */
}

#endif

/*--------------------------------------------------------------*/

TDAG
pre_process_instance(TDAG src)
{
  TDAG quant, instance, lemma;
  assert(DAG_arity(src) == 2);
  quant = DAG_arg0(src);
  instance = DAG_dup(DAG_arg1(src));
  if (pre_quantifier && DAG_quant(instance))
    instance = pre_quant_ite(instance);
  else
    instance = pre_ite(instance);
  if (!disable_simp)
    {
      if (!disable_ctx)
        instance = simplify_formula(instance);
      else
        instance = simplify_instance_old(instance);
    }
  lemma = DAG_dup(DAG_or2(quant, instance));

  /* this should come very last because it only tags formulas
     ground bit is used in congruence closure, and quantifier handling,
     so this should come before unit simplification */
  check_free_shadowed_vars(lemma);
  /* [TODO] how to avoid working on ground terms which were already checked? */
  /* sets variables infrastructure */
  set_fvars(lemma);
  DAG_free(src);
  DAG_free(instance);
  return lemma;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

TDAG
pre_process_instance_proof(TDAG src, Tproof * Pproof)
{
  TDAG quant, instance, lemma;
  Tproof proof;
  assert(DAG_arity(src) == 2);
  quant = DAG_arg0(src);
  instance = DAG_dup(DAG_arg1(src));
  /* quantifier handling (skolem, tidy, simplify) is sensitive to HOL
     it should come after HOL elimination */
  proof_subproof_begin(ps_type_subproof);
  proof = proof_add_input(instance);
  if (pre_quantifier && DAG_quant(instance))
    instance = pre_quant_ite_proof(instance, &proof);
  else
    instance = pre_ite_proof(instance, &proof);
  if (!disable_simp && !disable_ctx)
    instance = simplify_formula_proof(instance, &proof);
  if (DAG_arg1(src) != instance)
    {
      Tproof proof1, proof2, proof3;
      proof = proof_subproof_end_input();
      lemma = DAG_dup(DAG_or2(quant, instance));
      proof1 = proof_or(*Pproof);
      proof2 = proof_or_neg(lemma, 0);
      proof3 = proof_or_neg(lemma, 1);
      *Pproof = proof_resolve(4, proof1, proof, proof2, proof3);
    }
  else
    {
      proof_subproof_remove();
      lemma = DAG_dup(src);
    }
  /* this should come very last because it only tags formulas
     ground bit is used in congruence closure, and quantifier handling,
     so this should come before unit simplification */
  check_free_shadowed_vars(lemma);
  /* [TODO] how to avoid working on ground terms which were already checked? */
  /* sets variables infrastructure */
  set_fvars(lemma);
  DAG_free(src);
  DAG_free(instance);
  return lemma;
}
#endif

/*--------------------------------------------------------------*/

void
pre_init(void)
{
  qnt_tidy_init();
  skolemize_init();
  qnt_simplify_init();
  simp_sym_init();
  bclauses_init();
  options_new(0, "old-processing", "Use old monolithic processing.",
              &disable_ctx);
  options_new(0, "disable-simp", "Disable simplification of expressions.",
              &disable_simp);
  options_new(0, "disable-unit-simp",
              "Disable unit clause propagation as simplification."
              "Only available in non-interactive mode",
              &disable_unit_simp);
  options_new(0, "disable-unit-subst-simp",
              "Disables unit clause rewriting as simplification."
              "Only available in non-interactive mode",
              &disable_unit_subst_simp);
  options_new(0, "disable-ackermann",
              "Disable local Ackermannization and elimination of rare symbols.",
              &disable_ackermann);
  options_new(0, "disable-sym",
              "Disable symmetry breaking.",
              &disable_sym);
  options_new(0, "enable-assumption-simp", "Enable simplifications of assumptions",
              &enable_assumption_simp);
  options_new(0, "enable-nnf-simp", "Qnt formulas into NNF, with var renaming",
              &enable_nnf_simp);
  options_new(0, "disable-bclause",
              "Do not optimize for binary clauses.",
              &disable_bclause);
  pre_quantifier = true;
}

/*--------------------------------------------------------------*/

void
pre_logic(char * logic)
{
  if (strcmp(logic, "QF_UF") == 0 ||
      strcmp(logic, "QF_UFIDL") == 0 ||
      strcmp(logic, "QF_IDL") == 0 ||
      strcmp(logic, "QF_RDL") == 0 ||
      strcmp(logic, "QF_LRA") == 0 ||
      strcmp(logic, "QF_UFLRA") == 0 ||
      strcmp(logic, "QF_LIA") == 0 ||
      strcmp(logic, "QF_UFLIA") == 0)
    pre_quantifier = false;
  else
    pre_quantifier = true;
  if (strcmp(logic, "QF_RDL") == 0 ||
      strcmp(logic, "QF_IDL") == 0 ||
      strcmp(logic, "QF_LRA") == 0 ||
      strcmp(logic, "QF_LIA") == 0)
    pre_eq = true;
}

/*--------------------------------------------------------------*/

void
pre_done(void)
{
  bclauses_done();
  simp_sym_done();
  qnt_tidy_done();
  skolemize_done();
  qnt_simplify_done();
}
