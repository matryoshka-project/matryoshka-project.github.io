/*
  --------------------------------------------------------------
  Module for polishing quantified formulas
  --------------------------------------------------------------
*/

/*
  DD+PF
  Originally created by DD+PF (august 2007?)
  Code review (EXCEPT Canonize) by PF in april 2008
  Code review global by PF in august 2008
*/

#ifndef __QNT_TIDY_OLD_H
#define __QNT_TIDY_OLD_H

#include "DAG.h"

/**
   \brief rename quantified variables so that no formula is in the
   scope of two quantifiers on the same variable
   \remarks two different variables may have the same name, if they
   have different sorts
   \remarks outermost variables are renamed first
   \remarks DAG should be lambda-free and apply-free (test included)
   \remarks Tolerant to ite terms
   \remarks DAG-Linear with respect to the quantifier-free part,
   tree-Linear with respect to the quantified part
   \remarks Non-destructive
   \pre DAG should be lambda-free (test included) */
TDAG     qnt_tidy(TDAG DAG);

/**
   \brief PF Sets the DAG->ground bit of ground formulas inside
   quantified formulas.
   \par(Complexity) DAG-Linear with respect to the quantifier-free part DAG
   should be lambda-free and apply-free (test included). Tree-Linear
   with respect to the quantified part
   \remark Tolerant to apply, macros, ite terms
   \pre DAG should be lambda-free (test included)
   \pre DAG should not contain nested quantifiers on the same variable
   (qnt_tidy rewrites such cases) */
void     qnt_ground(TDAG DAG);

/**
   \brief DD Performs the following simplifications:
   \f{eqnarray*}{
   \forall x, x \neq T \lor \phi(x) & \longrightarrow & \phi(T) \\
   \exists x, x = T \land \phi(x) & \longrightarrow & \phi(T)
   \f}
   if \f$T\f$ only contains variables that have a larger scope than \f$x\f$.
   \note better call (boolean) simplify after
   \note Non-destructive */
TDAG     qnt_simplify(TDAG src);

void     qnt_simplify_init(void);
void     qnt_simplify_done(void);

#endif /* __QNT_TIDY_H */
