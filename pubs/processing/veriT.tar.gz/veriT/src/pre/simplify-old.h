/*
  --------------------------------------------------------------
  Module for simplifying formulas and terms
  --------------------------------------------------------------
*/

#ifndef __SIMPLIFY_OLD_H
#define __SIMPLIFY_OLD_H

/* PF

   simplify_formula:
   simple transformation rules applied to obtain a formula that is
   logically equivalent to the input and hopefully simpler.
   The transformation is linear with respect to the size of the formula.
   src may contain quantifiers, lambda, apply, ...

   Code reviewed by PF in august 2008
*/

#include "DAG.h"

void      simplify_init(void);
void      simplify_done(void);

/* PF some simple linear rules - DD destructive
   the reference counter of result is at least 1. */
TDAG      simplify_formula_old(TDAG src);

/* PF some simple linear rules - DD destructive
   the reference counter of result is at least 1.
   obs. differs from simplify_formula in that it does
   not assume that it is a conjunction. */
TDAG      simplify_instance_old(TDAG src);

/**
   \author Pascal Fontaine
   \brief realizes some unit clause propagation, i.e, for
   x = T and phi(x), rewrites to phi(T)
   \remarks this is programmed in an quadratic way, can be improved
   \remarks should not be applied in incremental mode */
TDAG      simplify_formula_sat(TDAG src);

/* DD remove useless assumptions - assumes that src is a conjunction s.t.
   assumptions come first, followed by goal formula */
TDAG      simplify_benchmark(TDAG src);

#endif /* __SIMPLIFY_H */
