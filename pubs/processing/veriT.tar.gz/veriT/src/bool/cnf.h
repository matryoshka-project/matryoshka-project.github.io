/*
  --------------------------------------------------------------
  Conjunctive normal form
  --------------------------------------------------------------
*/

#ifndef __CNF_H
#define __CNF_H

#include "config.h"

#include "DAG.h"
#include "bool.h"
#include "proof-id.h"

/*--------------------------------------------------------------*/

/**
   \brief add clauses for cnf associated with DAG
   \param DAG the formula
   \param Pclauses a pointer to a stack of clauses where to add cnf */
void cnf(TDAG DAG, Tstack_clause *Pclauses);

/*--------------------------------------------------------------*/

#ifdef PROOF
/**
   \brief add clauses for cnf associated with DAG
   \param DAG the formula
   \param Pclauses a pointer to a stack of clauses where to add cnf
   \param proof the proof */
void cnf_proof(TDAG DAG, Tstack_clause * Pclauses, Tproof proof);
#endif

/*--------------------------------------------------------------*/

void cnf_init(void);
void cnf_done(void);
void cnf_reset(void);

#endif /* __CNF_H */
