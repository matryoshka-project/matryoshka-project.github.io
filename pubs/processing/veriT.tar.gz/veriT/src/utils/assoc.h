/* 
   ------------------------------------------------------------------- 
   Association (pair) key-value
   ------------------------------------------------------------------- 
*/
#ifndef __ASSOC_H
#define __ASSOC_H

typedef struct TSassoc {
  void * key;
  void * value;
} * Tassoc;

#endif /* __ASSOC_H */
